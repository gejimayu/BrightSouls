#ifndef loaddata_H
#define loaddata_H

#define MARK '.'
#define BLANK ' '

#include "boolean.h"
#include "data.h"
#include "point.h"
/*variabel Global Data*/
extern Data Musuh[6+1];
extern Data Boss;
extern Data Player;
extern Point PosisiPlayer;
extern int MapNow;
/*Prosedur yang mengelola ADT Data*/
void ReadFile(char NamaArsip[50],char c);/*buat ngebaca data enemy ama boss*/
void loadPlayer(char NamaArsip[20]);/*ngeload data player (bonus)*/
void loadPoint();
void loadmapnow();



#endif

