#ifndef queue_H
#define queue_H

#define Nill 0

#define Head(Q) (Q).Head
#define Tail(Q) (Q).Tail
#define InfoHead(Q) (Q).Aksi[(Q).Head]
#define InfoTail(Q) (Q).Aksi[(Q).Tail]

// representasi Queue alternatif 1
typedef struct {
	char Aksi[4+1];
	int Head;	// indeks tabel
	int Tail;	// indeks tabel
} Queue;

void CreateEmptyQ (Queue * Q);
/*
	I.S. sembarang
	F.S. Sebuah Q kosong terbentuk HEAD=Nil dan TAIL=Nil.
*/

boolean IsEmptyQ (Queue Q);
/* Mengirim true jika Q kosong: lihat definisi di atas */

boolean IsFullQ (Queue Q);
/* Mengirim true jika tabel penampung elemen Q sudah penuh */
/* yaitu mengandung elemen sebanyak 4 */

void Add (Queue * Q, char X);
/*
	Proses: Menambahkan X pada Q dengan aturan FIFO
	I.S. Q mungkin kosong, tabel penampung elemen Q TIDAK penuh
	F.S. X menjadi TAIL yang baru, TAIL "maju"
		Jika Tail(Q) = 4+1 Maka geser isi tabel, shg Head(Q) = 1
*/
		  
void Del (Queue * Q, char * X);
/*
	Proses: Menghapus X pada Q dengan aturan FIFO
	I.S. Q tidak mungkin kosong
	F.S. X = nilai elemen HEAD pd I.S., HEAD "maju", 
		Q mungkin kosong.
*/

void PrintQueue (Queue Q);
/* Mencetak isi queue Q ke layar */


void PrintQueueP (Queue Q);

#endif
