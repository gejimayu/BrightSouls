#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <termios.h>
#include <unistd.h>
#include "data.h"
#include "save.h"

#include "save.c"

#include "matriks.c"

#include "stack.c"

#include "queue.c"

#include "bacaenemy.c"

#include "loaddata.c"

#include "loadskill.c"

#include "graph.c"




// ------------------------VARIABLE GLOBAL------------------------------------------

 int HPMax;
 int MapNow;
 int MusuhNow;
 Point PosisiPlayer;
 Data Musuh[6+1];
 Data Boss;
 Data Player;
 Matriks Peta[3+1];
 List SambunganPeta[3+1];
 int NextPosisiY;
 int NextPosisiX;
 int NBaris;
 int NKolom;
 BinTree SkillPlayer;
 Stack AksiMusuh;
 Stack AksiBoss;
 boolean Keluar;


typedef struct {
		char strs[10][200];
} Kata;

//------------------------PROSEDUR TAMBAHAN----------------------------------------

int strleng(char *s)
{
	int i;
	for(i = 0; s[i] != '\0'; ++i);
}

int stringcompare (char a[], char b[])
{
	 int c = 0;
 
	   while (a[c] == b[c]) {
	      if (a[c] == '\0' || b[c] == '\0')
		 break;
	      c++;
	   }
	 
	   if (a[c] == '\0' && b[c] == '\0')
	      return 0;
	   else
	      return -1;
}

int getch(void)
{
    struct termios oldattr, newattr;
    int ch;
    tcgetattr( STDIN_FILENO, &oldattr );
    newattr = oldattr;
    newattr.c_lflag &= ~( ICANON | ECHO );
    tcsetattr( STDIN_FILENO, TCSANOW, &newattr );
    ch = getchar();
    tcsetattr( STDIN_FILENO, TCSANOW, &oldattr );
    return ch;
}

void delay(int milliseconds)
{
  long pause;
  clock_t now,then;

  pause = milliseconds*(CLOCKS_PER_SEC/1000);
  now = then = clock();
  while ((now-then) < pause)
    now = clock();
}


void PrintAksiMusuhHid(char Xcmd[5], int R1, int R2, int bacaAksi)
{
	int i= bacaAksi;
	while(i<=4)
	{
		if((i == R1 || i == R2) && (i != bacaAksi))
		{
			printf("# ");
		}
		else
		{
			printf("%c ", Xcmd[i]);
		}
		i++;
	}
}

int kalkulasi(int x,int y)
{
	if ((x-y) < 0)
		return 0;
	else
		return x-y;
}

boolean CekKalah(int x)
{
	return (x>0);
}

boolean naik_level(int lvl, int exp)
{
	return (((lvl == 1) && (exp >= 40)) || ((lvl == 2) && (exp >= 92)) || ((lvl == 3) && (exp >= 113)));
}

void concat(char s1[200], char s2[200])
{
	int i,j;
	for(i = 0; s1[i] != '\0'; ++i);

    for(j = 0; s2[j] != '\0'; ++j, ++i)
    {
        s1[i] = s2[j];
    }

    s1[i] = '\0';
}
void stringcopy(char s1[200], char s2[200])
{
	int i;
	for(i = 0; s1[i] != '\0'; ++i)
    {
        s2[i] = s1[i];
    }

    s2[i] = '\0';
}
void tostring(char str[], int num)
{
    int i, rem, len = 0, n;
    n = num;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
    for (i = 0; i < len; i++)
    {
        rem = num % 10;
        num = num / 10;
        str[len - (i + 1)] = rem + '0';
    }
    str[len] = ' ';
}

int generate()
	{
		int randomnumber;
		srand(time(NULL));
		randomnumber = rand() % 4;
		return (randomnumber+1);
	}

boolean Berantem(Stack AksiMusuh,Data Musuh, int maxronde)
/*
I.S. : Sembarang
F.S. : Menampilkan menu battle dan melakukan pertarungan 10 ronde.
		Proses pertarungan sebagai berikut :
		- Pop Queue (set aksi) dari Stack
		- Randomize aksi yang akan dipagari
		- Print set aksi enemy tersebut satu-satu dengan mekanisme Del Queue
		- Menerima input aksi dari user
		- Jika Player mati di tengah-tengah/akhir, maka GameOver()
		- Jika Enemy mati di tengah-tengah/akhir, maka Player berpindah tempat ke 'E'
		- Jika sudah 10 ronde tidak ada yang mati maka Player tidak terjadi apa-apa
*/
{
	boolean Kalah = true;
	boolean Keluar2 = false;
	Queue AksiNow;	
	CreateEmptyQ(&AksiNow);
	int ronde =1;
	char temp;
	while(ronde<=maxronde && !Keluar2)
	{

				int cnt,cnt2;
				int aksiKe=1;
				char cmd; /*Aksi Musuh*/
				char Xcmd[5]; /*Array Aksi Musuh*/
				char Xcmd2[5];
				Pop(&AksiMusuh, &AksiNow); /*Baca Queue Aksi Musuh Pertama dari Stack*/

				/*--------RANDOM ANGKA--------------*/
				int R1 = generate();
				int R2;
				do
				{
					R2 = generate();
				}
				while(R2==R1);
				/*---------------------------------------*/

				/*------BACA AKSI MUSUH---------------*/
				Queue aksiMusuhNow;
				CreateEmptyQ(&aksiMusuhNow);

				while(aksiKe<=4)
				{
					Del(&AksiNow,&cmd);
					Add(&aksiMusuhNow, cmd);
					Xcmd2[aksiKe] = cmd;
					if(aksiKe == R1 || aksiKe == R2)
					{
						Xcmd[aksiKe] = '#';
					}
					else
					{
						Xcmd[aksiKe] = cmd;
					}
					(aksiKe)++;
				}


				/*-----------BACA AKSI PLAYER------------*/
				Queue AksiPlayer;
				CreateEmptyQ(&AksiPlayer);

				char aksi,delAksi;
				cnt2 = 1;
				do
				{
					system("clear");
					printf("\n_____________________________________________________________\n");
					printf("   <%s>            |", Player.Nama);printf("HP: %d   | ", Player.HP);
					printf("STR: %d  | ", Player.STR);printf("DEF: %d  | ", Player.DEF);
					printf("Round %d |", ronde);
					printf("\n_____________________________________________________________\n");
					printf("    <%s>            |", Musuh.Nama);
					printf("HP: %d   | ", Musuh.HP);
					printf("Command:  ");
					for (cnt = 1; cnt <= 4; cnt++)
					{
						printf("%c ",Xcmd[cnt]);
					}
					printf("\n_____________________________________________________________\n");

					/*-----------------------------------------*/
					printf("\n   <%s> Attacked!\n",Musuh.Nama);
					printf("   Please input your command\n");
					printf("\n_____________________________________________________________");
					printf("\n   Inserted Commands:  | ");

					PrintQueue(AksiPlayer);

					printf("\n_____________________________________________________________");
					printf("\n");
					printf("   Command:	       | ");
					scanf(" %c", &aksi);
					
					if(aksi == 'A' || aksi == 'B' || aksi == 'F')
					{
						Add(&AksiPlayer, aksi);
					}
					else if(aksi == 'E')
					{
						Del(&AksiPlayer, &delAksi);
					}

					cnt2++;
				}
				while(!IsFullQ(AksiPlayer));
				/*--------------------------------------*/

				/*-------------------PRINT AKSI----------*/
				int bacaAksi = 1;
				int	hp,MusuhHPAwal;
				char next;
				char str[10];
				char aksiDone,M,P;
				char mark = '>';
				Queue aksiPlayerDone,aksiMusuhDone,cMusuh,cPlayer;
				CreateEmptyQ(&aksiPlayerDone);
				CreateEmptyQ(&aksiMusuhDone);
				CopyQueue(aksiMusuhNow, &cMusuh);
				CopyQueue(AksiPlayer, &cPlayer);
				Kata result;
				char hasil[200];

				/*****Menyimpan Musuh.HP Awal*****/
				MusuhHPAwal=Musuh.HP;

				while(bacaAksi <=4 && !Keluar2)
				{
					system("clear");

					/***********------------Memulai Battle------------------------**********/
					printf("\n_____________________________________________________________\n");
					printf("   <%s>            |", Player.Nama);printf("HP: %d   | ", Player.HP);
					printf("STR: %d  | ", Player.STR);printf("DEF: %d  | ", Player.DEF);
					printf("Round %d |", ronde);
					printf("\n_____________________________________________________________\n");
					printf("    <%s>             |", Musuh.Nama);
					printf("HP: %d   | ", Musuh.HP);
					printf("Command:  ");
					PrintQueueP(aksiMusuhDone);
					printf("%c", mark);
					PrintAksiMusuhHid(Xcmd2,R1,R2,bacaAksi);

					Del(&aksiMusuhNow, &aksiDone);
					Add(&aksiMusuhDone, aksiDone);

					/*-----------Command Kalkulasi Box----------*/
					printf("\n_____________________________________________________________\n");
					Del(&cMusuh, &M);
					Del(&cPlayer, &P);
					if(M == 'A' && P =='A')
					{
						stringcopy("There it is! Attacking each other!",result.strs[bacaAksi]);
					}
					else if(M == 'B' && P == 'B')
					{
						stringcopy("Strong defense for both side!",result.strs[bacaAksi]);
					}
					else if(M == 'F' && P == 'F')
					{
						stringcopy("Boom! Flanking each other!",result.strs[bacaAksi]);
					}
					else if(M == 'A' && P == 'B')
					{
						stringcopy(Musuh.Nama, hasil);
						concat(hasil," attacks ");
						concat(hasil,Player.Nama);
						concat(hasil," but it's blocked!");
						stringcopy(hasil,result.strs[bacaAksi]);
					}
					else if(M == 'A' && P == 'F')
					{
						hp = kalkulasi(Musuh.STR,Player.DEF);
						Player.HP = Player.HP - hp;
						stringcopy(Musuh.Nama, hasil);
						concat(hasil," attacks ");
						concat(hasil,Player.Nama);
						concat(hasil,"! ");
						concat(hasil,Player.Nama);
						concat(hasil," -");
						if (hp == 0)
						{
							concat(hasil,"0");
						}
						else
						{
							tostring(str,hp);
							concat(hasil,str);
						}
						concat(hasil," HP");
						stringcopy(hasil,result.strs[bacaAksi]);
					}
					else if(M == 'B' && P == 'A')
					{
						stringcopy(Player.Nama, hasil);
						concat(hasil," attacks ");
						concat(hasil,Musuh.Nama);
						concat(hasil," but it's blocked!");
						stringcopy(hasil,result.strs[bacaAksi]);
					}
					else if(M == 'B' && P == 'F')
					{
						hp = kalkulasi(Player.STR,Musuh.DEF);
						Musuh.HP = Musuh.HP - hp;
						stringcopy(Player.Nama, hasil);
						concat(hasil," flanks ");
						concat(hasil,Musuh.Nama);
						concat(hasil,"! ");
						concat(hasil,Musuh.Nama);
						concat(hasil," -");
						if (hp == 0)
						{
							concat(hasil,"0");
						}
						else
						{
							tostring(str,hp);
							concat(hasil,str);
						}
						concat(hasil," HP");
						stringcopy(hasil,result.strs[bacaAksi]);
					}
					else if(M == 'F' && P == 'B')
					{
						hp = kalkulasi(Musuh.STR,Player.DEF);
						Player.HP = Player.HP - hp;
						stringcopy(Musuh.Nama, hasil);
						concat(hasil," flanks ");
						concat(hasil,Player.Nama);
						concat(hasil,"! ");
						concat(hasil,Player.Nama);
						concat(hasil," -");
						if (hp == 0)
						{
							concat(hasil,"0");
						}
						else
						{
							tostring(str,hp);
							concat(hasil,str);
						}
						concat(hasil," HP");
						stringcopy(hasil,result.strs[bacaAksi]);
					}
					else if(M == 'F' && P == 'A')
					{
						hp = kalkulasi(Player.STR,Musuh.DEF);
						Musuh.HP = Musuh.HP - hp;
						stringcopy(Player.Nama, hasil);
						concat(hasil," attacks ");
						concat(hasil,Musuh.Nama);
						concat(hasil,"! ");
						concat(hasil,Musuh.Nama);
						concat(hasil," -");
						if (hp == 0)
						{
							concat(hasil,"0");
						}
						else
						{
							tostring(str,hp);
							concat(hasil,str);
						}
						concat(hasil," HP");
						stringcopy(hasil,result.strs[bacaAksi]);
					}
					int t;
					for(t=1;t<=bacaAksi;t++)
					{
						printf("%s\n", result.strs[t]);
						if(t==4)
							printf("Next round!\n");
					}
					/*---------------------------------*/

					/*--------Cek hasil battle--------*/
					if(!CekKalah(Player.HP))
					{
						Keluar2 = true;
						Kalah = true;
						printf("\n%s destroys you! Try again later!\n", Musuh.Nama);
						Musuh.HP = MusuhHPAwal;
						printf("GAME OVER !! \n");
						Keluar = true;
					}
					else if(!CekKalah(Musuh.HP))
					{
						Keluar2 = true;
						Kalah = false;
						printf("\nYou win! %s has defeated!\n", Musuh.Nama);
						Player.EXP += Musuh.EXP;
						if (naik_level(Player.LVL,Player.EXP))
						{
							printf("Level up !!\n");
							Player.LVL++;
							Player.EXP = 0;
						}
					}

					/*--------------------------------*
					/*----Selektor Aksi Player---*/
					printf("\n_____________________________________________________________");
					printf("\n|Inserted Command:		 | ");
					PrintQueueP(aksiPlayerDone);
					printf(" %c", mark);
					PrintQueueP(AksiPlayer);
					printf("                  |");
					Del(&AksiPlayer,&aksiDone);
					Add(&aksiPlayerDone, aksiDone);

					printf("\n_____________________________________________________________");

					/*-------Next Selektor-----*/
					getch();
					bacaAksi++;			
				}
				/*----------------------------------------*/


		ronde++; //next-ronde
	}
	return Kalah;
}
void LoadingScreen()
{
	system("clear");
	printf("                             ,                                \n");
  printf("                             @                                \n");
  printf("                             0,                               \n");
  printf("                            ,0;                               \n");
  printf("                            CGf                               \n");
  printf("                            0GG                               \n");
  printf("                            8C@                               \n");
  printf("     ;@@@@@@@@@@@           8C@                               \n");
  printf("    @@:C@@   @@@.           @C@      @.                       \n");
  printf("      ,@@@ G@@1   8C@@@@@@  @C@   ,8@@@@   8@@@. @@@,;@@@@8@@ \n");
  printf("      .@@@@@@@.   8@@  0@@  @L@ G@@@@,      @@   @@8, .@@@@:  \n");
  printf("      ,@@@8@@@@@  8@@ @@8   @L@ @@@.  88t   @@@@@@@t   @@@    \n");
  printf("      @@@G   .@@: 8@@@@@@   @L@ 0@@@   1@88f@@;  @@@   @@@    \n");
  printf("     ,@@@@@@@@@8 0@@@f 1@@  @f@  .@@@@@@@G @@@@ 8@@@.  @@@    \n");
  printf("     ........            ;@@@@@         @                     \n");
  printf("                           G80@        ,                      \n");
  printf("                       f00000000000L0                         \n");
  printf("                             @@                               \n");
  printf("                            1@L                               \n");
  printf("                            @@@L                      8.      \n");
  printf("                                                 @@@@@@@,     \n");
  printf("         @@@@@,    @@@@@    ,@@.   @@.;8@@       @@@@  .;     \n");
  printf("        t@@C      t@@L@@@   L@@    @0   @@        @@@@@@.     \n");
  printf("         ,8@@@8  @@t   @@@  @@@   i@@   @@       C  @@@@@@    \n");
  printf("        88  @@@@ @@@   @@@; @@@L ;@@@  i@@  f@ C@@@:  ,@@@    \n");
  printf("       @@@@@@@@,  @@@@@@0    :@@@@@t   @@@@@@@ 0 .@@@@@@8     \n");
  printf("\n"); delay(2000);

  int i,j;

  for (i=0; i<=13; i++) {
    system("clear");
    printf("\n");
    printf("\n");
    printf("\n");
    printf("\n");
    printf("\n");
    printf("\n");
    printf("\n");
    printf("                           LOADING  \n");
    for (j=12-i; j>=0; j--) {
      printf("                         ▒▒▒▒▒▒▒▒▒▒▒\n");
    }
    for (j=i; j>=0; j--) {
      printf("                         ███████████\n");
    }
    delay(350);
  }
  printf("\n");
}
void TampilMenu(int *Cmd)
{
	int temp;
	system("clear");

  printf("        ████    ████     ███      ███████  ████   ████        \n");
  printf("         ████  ████     ██ ██       ███     ████   ██         \n");
  printf("         ██ ████ ██    ██   ██      ███     ██  ██ ██         \n");
  printf("         ██  ██  ██   █████████     ███     ██   ████         \n");
  printf("        ████    ████ ████   ████  ███████  █████  ███         \n");
  printf("												 	                                    \n");
  printf("        ████    ████ █████████  ████   ██  ██     ██          \n");
  printf("         ████  ████   ██         ████  ██  ██     ██          \n");
  printf("         ██ ████ ██   █████      ██ ██ ██  ██     ██          \n");
  printf("         ██  ██  ██   ██         ██  ████  ██     ██          \n");
  printf("        █████  █████ █████████  ████  ███   ███████	          \n");
  printf("                                                              \n");
  printf("       ░░░░░░░░░░░░░░░░░░░░░░   ░░░░░░░░░░░░░░░░░░░░░         \n");
  printf("       ░░██░░░█░█████░█░░░█░░   ░░░███░█░░░█░█░███░░░         \n");
  printf("       ░░█1█░░█░█░░░░░█░░░█░░   ░░░█4░░░█░█░░█░░█░░░░         \n");
  printf("       ░░█░░█░█░███░░░█░█░█░░   ░░░██░░░░█░░░█░░█░░░░         \n");
  printf("       ░░█░░░██░█░░░░░██░██░░   ░░░█░░░░█░█░░█░░█░░░░         \n");
  printf("       ░░█░░░░█░█████░█░░░█░░   ░░░███░█░░░█░█░░█░░░░         \n");
  printf("       ░░░░░░░░░░░░░░░░░░░░░░   ░░░░░░░░░░░░░░░░░░░░░         \n");
  printf("                                                              \n");
  printf("       ░░░░░░░░░░░░░░░░░░░░░░   ░░░░░░░░░░░░░░░░░░░░░         \n");
  printf("       ░████░███░███░███░███░   ░░░█░░░███░███░██░░░░         \n");
  printf("       ░██2░░░█░░█░█░█░█░░█░░   ░░░█3░░█░█░█░█░█░█░░░         \n");
  printf("       ░░██░░░█░░█░█░██░░░█░░   ░░░█░░░█░█░█░█░█░█░░░         \n");
  printf("       ░░░██░░█░░███░█░█░░█░░   ░░░█░░░█░█░███░█░█░░░         \n");
  printf("       ░████░░█░░█░█░█░░█░█░░   ░░░███░███░█░█░██░░░░         \n");
  printf("       ░░░░░░░░░░░░░░░░░░░░░░   ░░░░░░░░░░░░░░░░░░░░░         \n");
  printf("         Copyright© 2016 Kelompok 06 Alstrukdat K1            \n");
  printf("                                                              \n");
  printf("           ENTER YOUR COMMAND HERE (1-4) : "); scanf("%d",&temp);
	*Cmd = temp;
}

void TampilPenjelajahan()
{
	int x;

	printf("%s",Player.Nama);
	if (strleng(Player.Nama) < 9)
	{
		for (x = 1; x <= 9 - strleng(Player.Nama); x++)
		{
			printf(" ");
		}
	}
	printf("  | ");
	printf("LVL:%d",Player.LVL);
	printf("   | ");
	printf("HP:%d",Player.HP);

	if (Player.HP / 10 == 0)
	{
		printf("    | ");
	}
	else if (Player.HP / 10 > 0)
	{
		printf("   | ");
	}
	printf("STR:%d",Player.STR);

	if (Player.STR / 10 == 0)
	{
		printf("   | ");
	}
	else if (Player.STR / 10 > 0)
	{
		printf("  | ");
	}
	printf("DEF:%d",Player.DEF);

	if (Player.DEF / 10 == 0)
	{
		printf("   | ");
	}
	else if (Player.DEF / 10 > 0)
	{
		printf("  | ");
	}
	printf("EXP:%d",Player.EXP);

	if (Player.EXP / 10 < 10)
	{
		printf("  |");
	}
	else if (Player.EXP / 10 >= 10)
	{
		printf(" |");
	}
	printf("\n");

	int i,j,k;

	for (i = 0; i < Peta[MapNow].NBaris; i++)
	{

		for (k = 1; k <= 11; k++)
		{
			printf(" ");
		}
		// printf("|");

		for (j = 0; j < Peta[MapNow].NKolom; j++)
		{
			printf("  %c  ",Peta[MapNow].M[i][j]);
		}
		printf("\n");
	}
}

void PindahMap()
/*
I.S. : Sembarang
F.S. : Mencari map sebelahnya dengan KoorAwal dan KoorAkhir yang cocok
*/
{
	address1 P;

	P = SearchG(SambunganPeta[MapNow],PosisiPlayer);
	Peta[MapNow].M[Ordinat(PosisiPlayer)][Absis(PosisiPlayer)]  = '-';
	MapNow = InfoG(P);
	PosisiPlayer = KoorAkhir(P);
	Peta[MapNow].M[Ordinat(PosisiPlayer)][Absis(PosisiPlayer)] = 'P';
}

void Gerak(char Cmd)
/*
I.S. : Sembarang
F.S. : Cek dahulu posisi berikutnya.
		Jika 1 Posisi berikutnya
		: berada pada di luar batas map maka PindahMap();
		: '#' maka player tidak pindah;
		: 'M' maka player pindah dan HP jadi penuh;
		: 'E' maka tampil battle Berantem();
		: '-' player pindah;
		: 'B' maka tampil battle BerantemBoss();
*/
{
	Point NextPosisi;
	Absis(NextPosisi) = 0;
	Ordinat(NextPosisi) = 0;

	if (Cmd == 'U')
	{
		Absis(NextPosisi) = Absis(PosisiPlayer);
		Ordinat(NextPosisi) = Ordinat(PosisiPlayer) - 1;
	}
	else if (Cmd == 'D')
	{
		Absis(NextPosisi) = Absis(PosisiPlayer);
		Ordinat(NextPosisi) = Ordinat(PosisiPlayer) + 1;
	}
	else if (Cmd == 'L')
	{
		Absis(NextPosisi) = Absis(PosisiPlayer) - 1;
		Ordinat(NextPosisi) = Ordinat(PosisiPlayer);
	}
	else if (Cmd == 'R')
	{
		Absis(NextPosisi) = Absis(PosisiPlayer) + 1;
		Ordinat(NextPosisi) = Ordinat(PosisiPlayer);
	}

	if ((Ordinat(NextPosisi) < 0) || (Ordinat(NextPosisi) > (NBaris-1)) || (Absis(NextPosisi) < 0) || (Absis(NextPosisi) > (NKolom-1)))
	{
		PindahMap();
	}
	else if (Peta[MapNow].M[Ordinat(NextPosisi)][Absis(NextPosisi)] == 'M')
	{
		Player.HP = HPMax;
		Peta[MapNow].M[Ordinat(PosisiPlayer)][Absis(PosisiPlayer)] = '-';
		Peta[MapNow].M[Ordinat(NextPosisi)][Absis(NextPosisi)] = 'P';
		PosisiPlayer = NextPosisi;
	}
	else if (Peta[MapNow].M[NextPosisi.Y][NextPosisi.X] == 'E')
	{
		if (!Berantem(AksiMusuh,Musuh[MusuhNow],10))  //menang
		{
			Peta[MapNow].M[Ordinat(PosisiPlayer)][Absis(PosisiPlayer)] = '-';
			Peta[MapNow].M[Ordinat(NextPosisi)][Absis(NextPosisi)] = 'P';
			PosisiPlayer = NextPosisi;
			MusuhNow++;
		}
	}
	else if (Peta[MapNow].M[NextPosisi.Y][NextPosisi.X] == 'B')
	{
		if(!Berantem(AksiBoss,Boss,20))
		{
			printf("Selamat anda menang.\n");
			Keluar = true;
		}
	}
	else if (Peta[MapNow].M[Ordinat(NextPosisi)][Absis(NextPosisi)] == '-')
	{
		Peta[MapNow].M[Ordinat(PosisiPlayer)][Absis(PosisiPlayer)] = '-';
		Peta[MapNow].M[Ordinat(NextPosisi)][Absis(NextPosisi)] = 'P';
		PosisiPlayer = NextPosisi;
	}
}

void Jelajah()
{
	char Cmd2[10];
	char Cmd3;
	int Cmd4;
	Keluar = false;
	do
	{
		system("clear");
		TampilPenjelajahan();
		printf("Command : ");
		scanf("%s",Cmd2);
		if (stringcompare(Cmd2,"GU") == 0)
		{
			Gerak(Cmd2[1]);
		}
		else if (stringcompare(Cmd2,"GD") == 0)
		{
			Gerak(Cmd2[1]);
		}
		else if (stringcompare(Cmd2,"GL") == 0)
		{
			Gerak(Cmd2[1]);
		}
		else if (stringcompare(Cmd2,"GR") == 0)
		{
			Gerak(Cmd2[1]);
		}
		else if (stringcompare(Cmd2,"SKILL") == 0)
		{
			PrintTree(SkillPlayer);
			printf("Skill yang diberi tanda (*) adalah skill yang telah diambil\n");
			printf("Silahkan nomor nama skill yang ingin diambil : ");
			scanf("%d",&Cmd4);
			if ((Cmd4 >= 1) && (Cmd4 <= 7))
			{
				BinTree P = SearchNode(SkillPlayer,Cmd4);
				if ((Akar(P).BolehAmbil) && (Akar(P).LvlReq <= Player.LVL))
				{
					HPMax += Akar(P).HP;
					Player.STR += Akar(P).STR;
					Player.DEF += Akar(P).DEF;
					Akar(P).BolehAmbil = false; //sudah tidak dapat diambil lagi
					Akar(P).SudahAmbil = true;
					Akar(Left(P)).BolehAmbil = true;  //anaknya boleh diambil
					Akar(Right(P)).BolehAmbil = true;
					printf("Anda telah berhasil mengambil skill tersebut \n");
				}
				else
				if (Akar(P).SudahAmbil)
					printf("Skill sudah pernah diambil\n");
				else
					printf("Skill belum bisa diambil karena belum memenuhi syarat\n");
			}
			else
				printf("Skill tidak ada\n");
			getch();
			getch();
		}
		else if (stringcompare(Cmd2,"SAVE") == 0)
		{
			//Save(); save skill
			EksternalDataPlayer("dataplayerload.txt");
			savejam();
			savepoint();
			savemap();
			savemapnow();
		}
		else if (stringcompare(Cmd2,"LOAD") == 0)
		{
			//Load(); load skill, tergantung save skill
			loadPoint();
			LoadMap("maphasilsave.txt");
			loadPlayer("dataplayerload.txt");
			loadmapnow();
		}
		else if (stringcompare(Cmd2,"EXIT") == 0)
		{
			Keluar = true;
		}
		else
		{
			printf("Command tidak dikenali, silahkan ulangi\n");
			getch();
			getch();
		}
	} while (!Keluar);
}



// -----------------------------PROGRAM UTAMA-------------------------


int main()
{
	// KAMUS
	int Cmd;
	boolean CekNama,EndLoop,Keluar;
	char Cmd3;
	Point PAwal,PAkhir;

	//Proses Load Program
	LoadMap("map.txt");
	BacaSkill();
	ReadFileStack("AKSIMUSUH.txt",'M');
	ReadFileStack("AKSIBOSS.txt",'B');
	ReadFile("datamusuh.txt",'E');
	ReadFile("databoss.txt",'B');

	// INISIALISASI
	CekNama = false;
	EndLoop = false;
	Keluar = false;
	HPMax = 25;
	MapNow = 1;
	MusuhNow = 1;
	NBaris = 7;
	NKolom = 7;

	Absis(PosisiPlayer) = 3;
	Ordinat(PosisiPlayer) = 3;
	Peta[MapNow].M[Ordinat(PosisiPlayer)][Absis(PosisiPlayer)] = 'P';    //memasukkan player pada map

	//menginisialisasi graph
	CreateEmpty(&SambunganPeta[1]);
	CreateEmpty(&SambunganPeta[2]);
	CreateEmpty(&SambunganPeta[3]);
	//map1 <6,2> menyambung ke map2 <0,4>
	Ordinat(PAwal) = 2;
	Absis(PAwal) = 6;
	Ordinat(PAkhir) = 4;
	Absis(PAkhir) = 0;
	InsVLastG(&SambunganPeta[1],2,PAwal,PAkhir);
	//map1  <3,6> menyambung ke map3 <3,0>
	Ordinat(PAwal) = 6;
	Absis(PAwal) = 3;
	Ordinat(PAkhir) = 0;
	Absis(PAkhir) = 3;
	InsVLastG(&SambunganPeta[1],3,PAwal,PAkhir);
	//map2  <0,4> menyambung ke map1 <6,2>
	Ordinat(PAwal) = 4;
	Absis(PAwal) = 0;
	Ordinat(PAkhir) = 2;
	Absis(PAkhir) = 6;
	InsVLastG(&SambunganPeta[2],1,PAwal,PAkhir);
	//map3  <3,0> menyambung ke map1 <3,6>
	Ordinat(PAwal) = 0;
	Absis(PAwal) = 3;
	Ordinat(PAkhir) = 6;
	Absis(PAkhir) = 3;
	InsVLastG(&SambunganPeta[3],1,PAwal,PAkhir);

	//menginisialisasi skill
	Akar(SkillPlayer).BolehAmbil = true;  //skill pertama dapat diambil


	// ALGORITMA
	LoadingScreen();
	do
	{
		TampilMenu(&Cmd);

		if (Cmd == 1)
		{
			do
			{
				printf("Masukkan nama player (maksimal 9 karakter): ");
				scanf("%s",Player.Nama);
				if (strleng(Player.Nama) > 9)
				{
					printf("Maksimal nama 9 karakter. silahkan ulangi\n");
					getch();
					getch();
				}
				else
				{
					CekNama = true;
				}
			} while (!CekNama);

		}
		else
		if (Cmd == 2)
		{
			if (!CekNama)
			{
				printf("Anda belum memasukkan nama\n");
				getch();
				getch();
			}
			else
			{
				Player.HP = 25;
				Player.LVL = 1;
				Player.STR = 9;
				Player.DEF = 2;
				Player.EXP = 0;
				Jelajah();
				EndLoop = true;
			}
		}
		else
		if (Cmd == 3)
		{
			// Load();
		    printf("Anda Memilih Menu Load\n");
		    loadPlayer("dataplayerload.txt");
		    LoadMap("maphasilsave.txt");
		    loadPoint();
		    loadmapnow();
		    //BacaSkill(); tergantung save skill
			Jelajah();
			EndLoop = true;
		}
		else
		if (Cmd == 4)
		{
			EndLoop = true;
		}
		else
		{
			printf("Masukkan tidak dikenali, silahkan ulangi\n");
			getch();
			getch();
		}

	} while (!EndLoop);

	return 0;
}
