// Nama : Gianfranco Fertino Hwandiano
// NIM : 13515118
// tanggal : 1 september 2016
// Topik : pengenalan C

#include <stdio.h>

int main() 
{
	char S[] = "ab";
	if (S[3] == 'x')
		printf("asd");
	
	
}