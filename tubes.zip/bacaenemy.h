/* File: bacaenemy.h */
/* Definisi Mesin Karakter */

#ifndef __BACA_ENEMY_H_
#define __BACA_ENEMY_H_

#define MARK '.'
#define BLANK ' '
#include "boolean.h"
#include "stack.h"

extern Stack AksiMusuh;
extern Stack AksiBoss;

void ReadFileStack(char NamaArsip[20],char c);/*buat ngebaca stack aksi musuh*/



#endif
