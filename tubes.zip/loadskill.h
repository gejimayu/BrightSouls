#ifndef skill_H
#define skill_H

#define MARK '.'
#define BLANK ' '

void BacaAngka(char tempS, int *jurus);

void BacaSkill();


#endif