#ifndef jam_H
#define jam_H

typedef struct {
	int H,M,S;
} Jam;

#define Hour(P) P.H
#define Minute(P) P.M
#define Second(P) P.S

#endif
