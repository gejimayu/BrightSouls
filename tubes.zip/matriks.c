#include <stdio.h>
#include "matriks.h"

FILE * fin;

Matriks Peta[3+1];
void LoadMap(char * map_name)
/*
	Untuk membuka file [NamaMap].txt
*/
{
	char tempS,enter;
	int i,j,k;
	fin = fopen(map_name,"r");
	for (k = 1; k <= 3; k++)
	{
		i = 0;
		j = 0;
		do
		{
			j = 0;
			do
			{
				fscanf(fin,"%c", &tempS);
				Peta[k].M[i][j] = tempS;
				j++;
			} while ((tempS != '|') && (tempS != '.'));
			i++;
		}while (tempS != '.');
		Peta[k].NBaris = i;
		Peta[k].NKolom = j-1;
		fscanf(fin,"%c", &enter);
	}
	
}
