#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bacaenemy.h"
/*ASUMSI, NAMA ENEMY GABOLEH DIAWALIN 'H','S','D',ATAU 'E' karena udah dipake buat pengenal di HP,STR,DEF,EXP respectively.*/

Stack AksiMusuh;
Stack AksiBoss;

FILE * fin;

void ReadFileStack(char NamaArsip[20],char c)/*buat ngebaca stack aksi musuh*/
{
    fin = fopen(NamaArsip,"r");
    char tempS,enter;
    int tempI;
    int j=0; /*counter*/
    do
    {   /*Ignore Blank*/
        fscanf(fin,"%c", &tempS);
        while ((tempS==BLANK) && (tempS!=MARK)){//ignoreBlank
            fscanf(fin,"%c", &tempS);
        } /*berarti bukan blank nih, bisa aja mark*/
        if (tempS==MARK){
             fclose(fin);
        }else {/*bukan mark, sans*/
                fscanf(fin,"%d",&tempI);/*baca indeks keberapa di queue*/
                fscanf(fin,"%c",&tempS);/*baca aksinya apa*/
                if (c=='M')
                {
                    if (tempI==4)/*kalo terakhir, indeks stack diincrement*/
                    {
                        AksiMusuh.SetAksi[j].Aksi[tempI-1] = tempS;
                        AksiMusuh.SetAksi[j].Head = 0;
                        AksiMusuh.SetAksi[j].Tail = 3;
                        j++;
                        fscanf(fin,"%c",&enter);
                    }
                    else
                    {
                        AksiMusuh.SetAksi[j].Aksi[tempI-1] = tempS;
                    }
                }
                else//BOS
                {
                    if (tempI==4)/*kalo terakhir, indeks stack diincrement*/
                    {
                        AksiBoss.SetAksi[j].Aksi[tempI-1] = tempS;
                        AksiBoss.SetAksi[j].Head = 0;
                        AksiBoss.SetAksi[j].Tail = 3;
                        j++;
                        fscanf(fin,"%c",&enter);
                    }
                    else
                    {
                        AksiBoss.SetAksi[j].Aksi[tempI-1] = tempS;
                    }

                }
            }
    }while(tempS!=MARK);
    if (c=='M')
    {
        AksiMusuh.Top = j-1;
    }
    else
    {
        AksiBoss.Top = j-1;
    }


}
