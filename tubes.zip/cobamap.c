#include <stdio.h>
#include <stdlib.h>
#include "matriks.h"
#include "matriks.c"	
#include "save.h"
#include "save.c"


Matriks Peta[3+1];

int main()
{
int i,j,k;
	for (k = 1; k <= 3; k++)
	{
		for(i = 0; i < 5; i++)
		{
			for (j = 0; j < 5; j++)
			{
				Peta[k].M[i][j] = '#';
			}
		}
	}

savemap();
return 0;
}

