#include <stdlib.h>
#include "graph.h"


/****************** TEST LIST KOSONG ******************/
boolean IsEmptyG (List L)
/* Mengirim true jika list kosong */
{
	return FirstG(L) == Nil;
}

/****************** PEMBUATAN LIST KOSONG ******************/
void CreateEmpty (List *L)
/* I.S. sembarang             */
/* F.S. Terbentuk list kosong */
{
	FirstG(*L) = Nil;
}

/****************** Manajemen Memori ******************/
address1 AlokasiG (infotype X, Point P1, Point P2)
/* Mengirimkan address hasil alokasi sebuah elemen */
/* Jika alokasi berhasil, maka address tidak nil, dan misalnya */
/* menghasilkan P, maka info(P)=X, Next(P)=Nil */
/* Jika alokasi gagal, mengirimkan Nil */
{
	address1 P;
	P = (address1) malloc (sizeof(ElmtList));
	if (P == Nil)
	{
		return Nil;
	}
	else
	{
		InfoG(P) = X;
		KoorAwal(P) = P1;
		KoorAkhir(P) = P2;
		NextG(P) = Nil;
		return P;
	}
}

/****************** PENCARIAN SEBUAH ELEMEN LIST ******************/
address1 SearchG (List L, Point P1)
/* Mencari apakah ada elemen list dengan Info(P)= X */
/* Jika ada, mengirimkan address elemen tersebut. */
/* Jika tidak ada, mengirimkan Nil */
{
	address1 P = FirstG(L);
	boolean found = false;
	
	while ((P != Nil) && (!found))
	{
		if ((Absis(KoorAwal(P)) == Absis(P1)) && (Ordinat(KoorAwal(P)) == Ordinat(P1)))
		{
			found = true;
		}
		else
		{
			P = NextG(P);
		}
	}
	return P;
}

/*** PENAMBAHAN ELEMEN BERDASARKAN ALAMAT ***/
void InsVLastG (List *L, infotype X, Point P1, Point P2)
/* I.S. L mungkin kosong */
/* F.S. Melakukan alokasi sebuah elemen dan */
/* menambahkan elemen list di akhir: elemen terakhir yang baru */
/* bernilai X jika alokasi berhasil. Jika alokasi gagal: I.S.= F.S. */
{
	address1 P,Last;
	
	P = AlokasiG(X,P1,P2);
	if (P != Nil)
	{
		if (IsEmptyG(*L))
		{
			NextG(P) = FirstG(*L);
			FirstG(*L) = P;
		}
		else
		{
			Last = FirstG(*L);
			while (NextG(Last) != Nil)
			{
				Last = NextG(Last);
			}
			NextG(P) = NextG(Last);
			NextG(Last) = P;
		}
	}
}
