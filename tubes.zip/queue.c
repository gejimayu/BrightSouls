#include <stdio.h>
#include "boolean.h"
#include "queue.h"

/* ********* Prototype ********* */
boolean IsEmptyQ (Queue Q)
/* Mengirim true jika Q kosong: lihat definisi di atas */
{
	return ( Head(Q) == Nill && Tail(Q) == Nill );
}
boolean IsFullQ (Queue Q)
/* Mengirim true jika tabel penampung elemen Q sudah penuh */
/* yaitu mengandung elemen sebanyak 4 */
{
	return ( Head(Q) == 1 && Tail(Q) == 4 );
}

/* *** Kreator *** */
void CreateEmptyQ (Queue * Q)
/* I.S. sembarang */
/* F.S. Sebuah Q kosong terbentuk: HEAD=Nill; TAIL=Nill. */
{
		Head(*Q) = Nill;
		Tail(*Q) = Nill;
}

void CopyQueue(Queue Q, Queue *Qout)
{
	*Qout = Q;
}
/* *** Primitif Add/Delete *** */
void Add (Queue * Q, char X)
/* Proses: Menambahkan X pada Q dengan aturan FIFO */
/* I.S. Q mungkin kosong, tabel penampung elemen Q TIDAK penuh */
/* F.S. X menjadi TAIL yang baru, TAIL "maju" dengan mekanisme circular buffer */
{

	int i, j;
		/* Algoritma */
		if (IsEmptyQ(*Q)) {
		Head(*Q)=1;
		Tail(*Q)++;
		InfoTail(*Q)=X;
		} else /* Q tidak kosong */ {
			if (Tail(*Q)==4) { /* Geser elemen Tail(*Q)  ke indeks 1 */
				Tail(*Q) = 1;
			} else {
				Tail(*Q)++;
			}

			InfoTail(*Q)=X;
		}
}

void Del (Queue * Q, char * X)
/* Proses: Menghapus X pada Q dengan aturan FIFO */
/* I.S. Q tidak mungkin kosong */
/* F.S. X = Nillai elemen HEAD pd I.S., HEAD "maju" dengan mekanisme circular buffer;
        Q mungkin kosong */
{
	*X = InfoHead(*Q);
		if (Head(*Q)==Tail(*Q)) { /* Set mjd queue kosong */
		Head(*Q)=Nill; Tail(*Q)=Nill;
		}
		else {
		if (Head(*Q)==4) { /* Geser elemen Head(*Q) maju  */
				Head(*Q) = 1;
			} else {
				Head(*Q)++;
			}
		}
}

void PrintQueue (Queue Q)
{
	if(IsEmptyQ(Q))
	{
		printf("_ _ _ _");
	} else
	{
		char X;
		int count =0;
		while(!IsEmptyQ(Q))
		{
			Del(&Q, &X);
			count++;
			printf("%c ", X);
		}
		if(count<=4)
		{
			int n = 4-count;
			int i;
			for(i=1;i<=n;i++)
			{
				printf("_ ");
			}
		}

	}
}

void PrintQueueP (Queue Q)
{
	if(IsEmptyQ(Q))
	{
		printf("");
	} else
	{
		char X;
		int count =0;
		while(!IsEmptyQ(Q))
		{
			Del(&Q, &X);
			count++;
			printf("%c ", X);
		}
	}
}
