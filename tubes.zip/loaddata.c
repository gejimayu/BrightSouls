#include <stdio.h>
#include <stdlib.h>
#include "loaddata.h"


FILE *fin;     // file buat nampung dari eksternal ke variabel
FILE *fout;     // file buat nanpung dari file ke eksternal
Data Musuh[6+1];
Data Boss;
Data Player;
Point PosisiPlayer;
int MapNow;
void ReadFile(char NamaArsip[50],char c)   // buat ngebaca data Musuh sama boss
/*
    prosedur buat baca file eksternal dimasukkan
    ke variabel (disini variabel data)
*/
{
    fin = fopen(NamaArsip,"r");
    char tempS,enter;
    int tempI;
    int i,j;    // counter
    j = 1;      //Musuh ke j
    do
    {
        fscanf(fin,"%c",&tempS);
        while ((tempS == BLANK) && (tempS != MARK))
		{ // ignoreBlank
            fscanf(fin,"%c",&tempS);
        } // berarti bukan blank nih, bisa aja mark
        if (tempS == MARK)
		{
             fclose(fin);
        }
		else
        /*
            kalo tempS =='H', sebagai pengenal HP,
            berarti lagi baca HP
        */
		{ // bukan mark, sans
            if (tempS == 'H')
			{
			    fscanf(fin,"%d",&tempI);
			    if (c=='E')
			    {
			        Musuh[j].HP = tempI;
                    // baca integer langsung ga perkarakter
			    }
			    else // c=='B'
                {
                    Boss.HP = tempI;
                }

            }
            else if (tempS == 'S')
			{    // baca STR
                fscanf(fin,"%d",&tempI);
			    if (c=='E')
                {
                    Musuh[j].STR = tempI;
                }
			    else //c=='B'
                {
                    Boss.STR = tempI;
                }

            }
			else if (tempS == 'D')
			{    // baca DEF
                fscanf(fin,"%d",&tempI);
                if (c=='E')
                {
                    Musuh[j].DEF = tempI;
                }
                else
                {
					Boss.DEF = tempI;
                }

            }
			else if (tempS == 'E')
			{    // ngebaca EXP
                fscanf(fin,"%d",&tempI);
                if (c=='E')
                {
                   Musuh[j].EXP = tempI;
                    j++;/*karena abis EXP berarti satu Musuh udah lengkap datanya, jadi di increment j nya*/
                }
                else
                {
                    Boss.EXP = tempI;
                }
				fscanf(fin,"%c",&enter);
            }
			else
			{   if (c=='E')
                {
			     // berarti ngebaca nama karakter
                    i = 0;
                    do
                    {
                        Musuh[j].Nama[i] = tempS;
                        fscanf(fin,"%c", &tempS);
                        i++;
                    } while (tempS != BLANK); // ketemu spasi
                }
                else
                {
                     i = 0;
                    do
                    {
                        Boss.Nama[i] = tempS;
                        fscanf(fin,"%c", &tempS);
                        i++;
                    } while (tempS != BLANK);
                }
            }
        }
    } while (tempS != MARK);

}

void loadPlayer(char NamaArsip[20])
{
    fin = fopen(NamaArsip,"r");
    char tempS,enter;
    int tempI;
    int i,j;    // counter
    j = 1;      //enemy ke j
    do
    {
        fscanf(fin,"%c",&tempS);
        while ((tempS == BLANK) && (tempS != MARK))
		{ // ignoreBlank
            fscanf(fin,"%c",&tempS);
        } // berarti bukan blank nih, bisa aja mark
        if (tempS == MARK)
		{
             fclose(fin);
        }
		else
        /*
            kalo tempS =='H', sebagai pengenal HP,
            berarti lagi baca HP
        */
		{ // bukan mark, sans
            if (tempS == 'H')
			{
			    fscanf(fin,"%d",&tempI);
                HP(Player) = tempI;
            }
            else if (tempS == 'S')
			{    // baca STR
                fscanf(fin,"%d",&tempI);
                STR(Player) = tempI;
            }
			else if (tempS == 'D')
			{    // baca DEF
                fscanf(fin,"%d",&tempI);
                DEF(Player) = tempI;
            }
			else if (tempS == 'E')
			{    // ngebaca EXP
                fscanf(fin,"%d",&tempI);
                EXP(Player) = tempI;
				//fscanf(fin,"%c",&enter); gatau kepake ga
            }
		else if (tempS == 'L')
		{
		fscanf(fin,"%d",&tempI);
		LVL(Player) = tempI;
		}
			else
			{
                    i = 0;
                    do
                    {
                        Player.Nama[i] = tempS;
                        fscanf(fin,"%c", &tempS);
                        i++;
                    } while (tempS != BLANK);
            }
        }
    } while (tempS != MARK);

}

void loadPoint()
{
    fin = fopen("point.txt","r");
    char tempS;
    int tempI;
    fscanf(fin,"%d",&Absis(PosisiPlayer));
    fscanf(fin,"%c",&tempS);
    fscanf(fin,"%d",&Ordinat(PosisiPlayer));
    fclose(fin);
}

void loadmapnow()
{
	fin = fopen("mapnow.txt","r");
	fscanf(fin,"%d",&MapNow);
	fclose(fin);
}

/* yang disave, skill, map, posisi*/

