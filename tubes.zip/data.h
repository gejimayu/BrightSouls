#ifndef data_H
#define data_H

#define Nil NULL
#define MARK '.'
#define BLANK ' '

#include "boolean.h"

typedef struct {
	char Nama[100];
	int HP,STR,DEF,EXP,LVL;
} Data;

#define HP(P) (P).HP
#define STR(P) (P).STR
#define DEF(P) (P).DEF
#define EXP(P) (P).EXP
#define LVL(P) (P).LVL
#define Nama(P) (P).Nama

#endif
