#ifndef matriks_H
#define matriks_H

typedef struct {
	char M[100][100];
	int NBaris,NKolom;
} Matriks;


extern Matriks Peta[3+1];

void LoadMap(char * map_name);
/*
	Untuk membuka file [NamaMap].txt
*/

#endif