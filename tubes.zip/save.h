#ifndef save_H
#define save_H

#define Nil NULL
#define MARK '.'
#define BLANK ' '

#include "boolean.h"
#include "data.h"
#include "point.h"
#include "matriks.h"


extern Data Player;
extern Point PosisiPlayer;
extern Matriks Peta[3+1];
extern int MapNow;
void EksternalDataPlayer(char NamaArsip[20]); /*Save Data Player */
void savejam();
void savepoint();
void savemap();
void savemapnow();

#endif




