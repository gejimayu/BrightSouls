#include <stdio.h>
#include <time.h>
#include "save.h"
#include "data.h"
#include "jam.h"
#include "point.h"

FILE *fout;
Data Player;
Point PosisiPlayer;
Matriks Peta[3+1];
extern int MapNow;

//Point posisi;
void EksternalDataPlayer(char NamaArsip[20]) /*ngesave data player ini*/
{
    fout = fopen(NamaArsip, "w");    /*langsung ngebuat baru file txt*/
    if (fout == NULL)
        exit(-1);
    fprintf(fout, "%s H%d S%d D%d E%d L%d .",Player.Nama,Player.HP,Player.STR,Player.DEF,Player.EXP,Player.LVL);
    fclose(fout);
}


void savejam()
{
    time_t now;
    Jam J;
    struct tm *now_tm;
    now = time(NULL);
    now_tm = localtime(&now);
    Hour(J) = now_tm->tm_hour;
    Minute(J) = now_tm->tm_min;
    Second(J) = now_tm->tm_sec;
    fout = fopen("savejam.txt","w");
    fprintf(fout, "%02d %02d %02d .",Hour(J),Minute(J),Second(J));
    fclose(fout);

}


void savepoint()
{
    fout = fopen("point.txt", "w");    /*langsung ngebuat baru file txt*/
    if (fout == NULL)
        exit(-1);
    fprintf(fout, "%d,%d .",Absis(PosisiPlayer), Ordinat(PosisiPlayer));
    fclose(fout);
}

void savemap()
{
	int i,j,k;
	fout = fopen("maphasilsave.txt","w");
	for (k = 1; k <= 3; k++)
	{
		for(i = 0; i < Peta[k].NBaris; i++)
		{
			for (j = 0; j < Peta[k].NKolom; j++)
			{
				fprintf(fout,"%c",Peta[k].M[i][j]);
			}
			if (i < (Peta[k].NBaris-1))
				fprintf(fout,"|");
			else
				fprintf(fout,".");
		}
		fprintf(fout,"\n");
	}
	fclose(fout);
}

void savemapnow()
{
	fout = fopen("mapnow.txt","w");
	fprintf(fout,"%d",MapNow);
	fclose(fout);
}

