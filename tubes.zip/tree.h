#ifndef tree_H
#define tree_H
#include "boolean.h"

typedef struct
{
	int NoSkill;
	char Nama[100];
	int LvlReq;
	int HP;
	int STR;
	int DEF;
	boolean SudahAmbil;
	boolean BolehAmbil;
} dataskill;
typedef struct tNode *addrNode;
typedef struct tNode {
	dataskill Info;
	addrNode Left;
	addrNode Right;
} Node;
typedef addrNode BinTree;

#define Akar(P) (P)->Info
#define Left(P) (P)->Left
#define Right(P) (P)->Right

extern BinTree SkillPlayer;

BinTree MakeTree (dataskill Akar, BinTree L, BinTree R); 
/* Menghasilkan sebuah pohon biner dari A, L, dan R, jika alokasi berhasil */
/* Menghasilkan pohon kosong (Nil) jika alokasi gagal */

addrNode AlokNode (dataskill Akar);
/* Mengirimkan addrNode hasil alokasi sebuah elemen */
/* Jika alokasi berhasil, maka addrNode tidak Nil, dan misalnya menghasilkan P, 
  maka Akar(P) = X, Left(P) = Nil, Right(P)=Nil */
/* Jika alokasi gagal, mengirimkan Nil */

boolean IsTreeEmpty (BinTree P);
/* Mengirimkan true jika P adalah pohon biner kosong */
boolean IsTreeOneElmt (BinTree P);
/* Mengirimkan true jika P adalah pohon biner tidak kosong dan hanya memiliki 1 elemen */
boolean IsUnerLeft (BinTree P);
/* Mengirimkan true jika pohon biner tidak kosong P adalah pohon unerleft: hanya mempunyai subpohon kiri */
boolean IsUnerRight (BinTree P);
/* Mengirimkan true jika pohon biner tidak kosong P adalah pohon unerright: hanya mempunyai subpohon kanan*/
boolean IsBiner (BinTree P);
/* Mengirimkan true jika pohon biner tidak kosong P adalah pohon biner: mempunyai subpohon kiri dan subpohon kanan*/

void PrintTree (BinTree P);
/* I.S. P terdefinisi, h adalah jarak indentasi (spasi) */
/* F.S. Semua simpul P sudah ditulis dengan indentasi (spasi) */
/* Penulisan akar selalu pada baris baru (diakhiri newline) */
/* Contoh, jika h = 2: 
1) Pohon preorder: (A()()) akan ditulis sbb:
A
2) Pohon preorder: (A(B()())(C()())) akan ditulis sbb:
A
  B
  C
3) Pohon preorder: (A(B(D()())())(C()(E()()))) akan ditulis sbb:
A
  B
    D
  C
    E
*/

boolean SearchTree (BinTree P, int X);
/* Mengirimkan true jika ada node dari P yang bernilai X */

BinTree SearchNode (BinTree P, int X);
/* Menghasilkan alamat node yang dicari dengan asumsi X pasti ada di salah satu node dari Tree P */


#endif