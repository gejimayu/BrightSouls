#ifndef graph_H
#define graph_H

#define Nil NULL
#define infotype int

#include "boolean.h"
#include "point.h"

typedef struct tElmtList *address1;
typedef struct tElmtList {
	int Info;  // map kesekian yang nyambung
	Point KoorAwal;
	Point KoorAkhir;
	address1 Next;
} ElmtList;
typedef struct {
	address1 First;
} List;

//SELECTOR

//suffix G artinya Graph untuk membedakan dengan selector dari ADT lain
#define InfoG(P) (P)->Info
#define KoorAwal(P) (P)->KoorAwal
#define KoorAkhir(P) (P)->KoorAkhir
#define NextG(P) (P)->Next
#define FirstG(P) (P).First
#define LastG(P) (P).Last

/*
	koordinat map sebelumnya, untuk mencocokkan
	misal map 1 titik (3,5) nyambung ke map 2 titik (2,1) dan 
	map 1 titik (5,1) nyambung ke map 3 titik (1,3)
	maka jika SambunganPeta[1].First->Info = 2, yg artinya map 1 nyambung ke map 2
	maka SambunganPeta[1].First->KoorAwal = <3,5>
	SambunganPeta[1].First->KoorAkhir = <2,1>
*/

/****************** TEST LIST KOSONG ******************/
boolean IsEmptyG (List L);
/* Mengirim true jika list kosong */

/****************** PEMBUATAN LIST KOSONG ******************/
void CreateEmptyG (List *L);
/* I.S. sembarang             */
/* F.S. Terbentuk list kosong */

/****************** Manajemen Memori ******************/
address1 AlokasiG (infotype X, Point P1, Point P2);
/* Mengirimkan address hasil alokasi sebuah elemen */
/* Jika alokasi berhasil, maka address tidak nil, dan misalnya */
/* menghasilkan P, maka info(P)=X, Next(P)=Nil */
/* Jika alokasi gagal, mengirimkan Nil */

/****************** PENCARIAN SEBUAH ELEMEN LIST ******************/
address1 SearchG (List L, Point P1);
/* Mencari apakah ada elemen list dengan Info(P)= X */
/* Jika ada, mengirimkan address elemen tersebut. */
/* Jika tidak ada, mengirimkan Nil */

/*** PENAMBAHAN ELEMEN BERDASARKAN ALAMAT ***/
void InsVLastG (List *L, infotype X, Point P1, Point P2);
/* I.S. L mungkin kosong */
/* F.S. Melakukan alokasi sebuah elemen dan */
/* menambahkan elemen list di akhir: elemen terakhir yang baru */
/* bernilai X jika alokasi berhasil. Jika alokasi gagal: I.S.= F.S. */

#endif