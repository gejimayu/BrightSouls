#include <stdio.h>
#include "loadskill.h"
#include "tree.c"

FILE * fin;
BinTree SkillPlayer;

void BacaAngka(char tempS, int *jurus)
// membaca 2 inputan string lalu mengonversinya ke integer
{
	char temp[3];
	int i = 0;
	int j;
	do
	{
		i++;
		temp[i] = tempS;
		fscanf(fin,"%c", &tempS);
	} while (tempS != BLANK);
	*jurus = 0;
				
	for(j = 1; j <= i; j++)
	{
		*jurus = (*jurus * 10) + (temp[j] - '0');
	}	
}

void BacaSkill()
{
	dataskill tempSkill;
	char tempS;
	int count = 0;		//untuk menghitung data ke berapa yg sedang dibaca
	int countskill = 0; //untuk menghitung skill keberapa yang sedang dibaca
	fin = fopen("Skill.txt","r");
	
	do
	{
		fscanf(fin,"%c",&tempS);
		while ((tempS == BLANK) && (tempS != MARK))
		{ //ignoreBlank
            fscanf(fin,"%c", &tempS);
        }
		if (tempS == MARK)
		{
			fclose(fin);
		}
		else
		{
			count++;
			if (count == 1) // namaskill
			{
				int k;
				
				countskill++;
				int i = 0;
				do
				{
					tempSkill.Nama[i] = tempS;
					fscanf(fin,"%c",&tempS);
					i++;
				} while (tempS != BLANK);
				tempSkill.Nama[i] = '\0';
			}
			else
			if (count == 2) // Level Requirement
			{
				BacaAngka(tempS,&tempSkill.LvlReq)	;	
			}
			else
			if (count == 3) // HP
			{
				BacaAngka(tempS,&tempSkill.HP);				
			}
			else
			if (count == 4) // STR
			{
				BacaAngka(tempS,&tempSkill.STR);				
			}
			else
			if (count == 5) // DEF
			{
				BacaAngka(tempS,&tempSkill.DEF);
				// selesai membaca data 1 skill lengkap
				tempSkill.SudahAmbil = false;
				tempSkill.BolehAmbil = false;
				tempSkill.NoSkill = countskill;
				if (countskill == 1) // skill pertama
					SkillPlayer = AlokNode(tempSkill);
				else
				if (countskill == 2) // skill kedua
					SkillPlayer->Left = AlokNode(tempSkill);
				else
				if (countskill == 3) // skill ketiga
					SkillPlayer->Right = AlokNode(tempSkill);
				else
				if (countskill == 4) // skill keempat
					SkillPlayer->Left->Left = AlokNode(tempSkill);
				else
				if (countskill == 5) // skill kelima
					SkillPlayer->Left->Right = AlokNode(tempSkill);
				else
				if (countskill == 6) // skill keenam
					SkillPlayer->Right->Left = AlokNode(tempSkill);
				else
				if (countskill == 7) // skill ketujuh
					SkillPlayer->Right->Right = AlokNode(tempSkill);
					
				count = 0;
				int k;
			}
		}
	} while (tempS != MARK);
}
