#ifndef point_H
#define point_H

typedef struct {
	int X,Y;
} Point;

//Selector

#define Absis(P) (P).X
#define Ordinat(P) (P).Y

#endif