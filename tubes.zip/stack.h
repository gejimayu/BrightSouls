#ifndef stack_H
#define stack_H
#include "queue.h"

#define Top(S) (S).Top
#define InfoTop(S) (S).SetAksi[(S).Top]

typedef struct {
	Queue SetAksi[20+1];    
	int Top;	// alamat top, indeks tabel
} Stack;

void CreateEmptyStack (Stack *S);
/*
	I.S. sembarang
	F.S. Membuat sebuah stack S kosong
		Ciri stack kosong : TOP bernilai Nil
*/

boolean IsEmptyStack (Stack S);
/* Mengirim true jika Stack kosong: lihat definisi di atas */

void Push (Stack * S, Queue X);
/*
	Menambahkan X sebagai elemen Stack S.
	I.S. S mungkin kosong, tabel penampung elemen stack TIDAK penuh
	F.S. X menjadi TOP yang baru,TOP bertambah 1
*/

void Pop (Stack * S, Queue * X);
/*
	Menghapus X dari Stack S
	I.S. S  tidak mungkin kosong
	F.S. X adalah nilai elemen TOP yang lama, TOP berkurang 1
*/

#endif
