#include <stdlib.h>
#include <stdio.h>
#include "boolean.h"
#include "tree.h"

BinTree SkillPlayer;

void stringcopy2(char s1[200], char s2[200])
{
	int i;
	for(i = 0; s1[i] != '\0'; ++i)
    {
        s2[i] = s1[i];
    }

    s2[i] = '\0';
}

BinTree MakeTree (dataskill Akar, BinTree L, BinTree R)
/*
	I.S. Sembarang
 	F.S. Menghasilkan sebuah pohon P
	Menghasilkan sebuah pohon biner P dari Akar, L, dan R
*/
{
	addrNode P;
	P = AlokNode(Akar);
	if (P != NULL)
	{
		Left(P)= L;
		Right(P) = R;
	}
	return P;
}

addrNode AlokNode (dataskill Akar)
/* Mengirimkan addrNode hasil alokasi sebuah elemen */
/* Jika alokasi berhasil, maka addrNode tidak NULL, dan misalnya menghasilkan P, 
  maka Akar(P) = X, Left(P) = NULL, Right(P)=NULL */
/* Jika alokasi gagal, mengirimkan NULL */
{
	addrNode P;
	P = (addrNode) malloc (sizeof(Node));
	if (P != NULL)
	{
		// assign akar ke pointer
		P->Info.NoSkill = Akar.NoSkill;
		stringcopy2 (Akar.Nama,P->Info.Nama);
		P->Info.LvlReq = Akar.LvlReq;
		P->Info.HP = Akar.HP;
		P->Info.STR = Akar.STR;
		P->Info.DEF = Akar.DEF;
		P->Info.SudahAmbil = Akar.SudahAmbil;
		P->Info.BolehAmbil = Akar.SudahAmbil;
		
		P->Left = NULL;
		P->Right = NULL;
		return P;
	}
}
boolean IsTreeEmpty (BinTree P)
/* Mengirimkan true jika P adalah pohon biner kosong */
{
	return P == NULL;
}
boolean IsTreeOneElmt (BinTree P)
/* Mengirimkan true jika P adalah pohon biner tidak kosong dan hanya memiliki 1 elemen */
{
	return (!IsTreeEmpty(P) && (Left(P) == NULL) && (Right(P) == NULL));
}
boolean IsUnerLeft (BinTree P)
/* Mengirimkan true jika pohon biner tidak kosong P adalah pohon unerleft: hanya mempunyai subpohon kiri */
{
	return (!IsTreeEmpty(P) && (Left(P) != NULL) && (Right(P) == NULL));
}
boolean IsUnerRight (BinTree P)
/* Mengirimkan true jika pohon biner tidak kosong P adalah pohon unerright: hanya mempunyai subpohon kanan*/
{
	return (!IsTreeEmpty(P) && (Left(P) == NULL) && (Right(P) != NULL));
}
boolean IsBiner (BinTree P)
/* Mengirimkan true jika pohon biner tidak kosong P adalah pohon biner: mempunyai subpohon kiri dan subpohon kanan*/
{
	return (!IsTreeEmpty(P) && (Left(P) != NULL) && (Right(P) != NULL));
}

void Acc (BinTree P, int h, int a)
{
	int i;
	if (!IsTreeEmpty(P))
	{
		if (Akar(P).SudahAmbil)
			printf("*");
		printf("%d.",Akar(P).NoSkill);
		
		printf("%s\n",Akar(P).Nama);
		
		if (!IsTreeEmpty(Left(P)))
		{
			for (i=1;i<=h*a;i++)
			{
				printf(" ");
			}
			Acc(Left(P),h,a+1);
		}
		if (!IsTreeEmpty(Right(P)))
		{
			for (i=1;i<=h*a;i++)
			{
				printf(" ");
			}
			Acc(Right(P),h,a+1);
		}
	}
}

void PrintTree (BinTree P)
/* I.S. P terdefinisi, h adalah jarak indentasi (spasi) */
/* F.S. Semua simpul P sudah ditulis dengan indentasi (spasi) */
/* Penulisan akar selalu pada baris baru (diakhiri newline) */
/* Contoh, jika h = 2: 
1) Pohon preorder: (A()()) akan ditulis sbb:
A
2) Pohon preorder: (A(B()())(C()())) akan ditulis sbb:
A
  B
  C
3) Pohon preorder: (A(B(D()())())(C()(E()()))) akan ditulis sbb:
A
  B
    D
  C
    E
*/
{		
	Acc(P,6,1);
}

boolean SearchTree (BinTree P, int X)
/* Mengirimkan true jika ada node dari P yang bernilai X */
{
	if (IsTreeEmpty(P))
	{
		return false;
	}
	else
	if (Akar(P).NoSkill == X)
	{
		return true;
	}
	else
	{
		return (SearchTree(Left(P),X) || SearchTree(Right(P),X));
	}
}

BinTree SearchNode (BinTree P, int X)
/* dengan asumsi X pasti ada di salah satu node dari Tree P */
{
	if (Akar(P).NoSkill == X)
	{
		return P;
	}
	else
	{
		if (SearchTree(Left(P),X))
			return SearchNode(Left(P),X);
		else
			return SearchNode(Right(P),X);
	}
}


